import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Student } from '../common/student';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  private baseUrl = 'http://localhost:8080/students';
  private baseUrlPag = 'http://localhost:8080/students-pagination';
  constructor(private httpClient: HttpClient) { }


  getStudent(theStudentId: number): Observable<Student> {
   console.log("Inside get student");
    // need to build URL based on student id
    console.log("student id is ",theStudentId);
    const studentUrl = `${this.baseUrl}/${theStudentId}`;
 
    
    console.log("formed get student url", studentUrl);

    return this.httpClient.get<Student>(studentUrl);
  }

  getStudentList(): Observable<Student[]> {
    console.log("Inside get student list");

    return this.httpClient.get<GetResponse>(this.baseUrlPag).pipe(
      map(response => response._embedded.students)
    );
  }

  getStudentListPaginate(thePage: number, 
    thePageSize: number): Observable<GetResponse> {

// need to build URL based on category id, page and size 
const searchUrl = `${this.baseUrlPag}?pageNo=${thePage}`
+ `&pageSize=${thePageSize}`;
console.log(" search url ",searchUrl)

return this.httpClient.get<GetResponse>(searchUrl);
}
}

interface GetResponse {
  _embedded: {
    students: Student[];
  },
  page: {
    size: number,
    totalElements: number,
    totalPages: number,
    number: number
  }
}
