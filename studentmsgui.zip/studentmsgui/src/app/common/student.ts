export class Student {
    
    rollNumber:number
    name:string
    marks:string
    subjects:[]
}
