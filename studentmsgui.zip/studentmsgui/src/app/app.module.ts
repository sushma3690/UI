import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { StudentsListComponent } from './components/students-list/students-list.component';
import { HttpClientModule } from '@angular/common/http';
import { StudentService } from './services/student.service';

import { Routes, RouterModule} from '@angular/router';
import { StudentDetailsComponent } from './components/student-details/student-details.component';
import {NgxPaginationModule} from 'ngx-pagination';



const routes: Routes = [
 // {path: 'students/:rollNumber', component: StudentDetailsComponent},
 // {path: 'students', component: StudentsListComponent}

{
  path: '',
  component: StudentsListComponent // the '' path will load Main students Component
},
{
  path: 'students/:rollNumber', component: StudentDetailsComponent},
];


const appRoutes: Routes = [

];

@NgModule({
  declarations: [
    AppComponent,
    StudentsListComponent,
    StudentDetailsComponent
  ],
  imports: [
    RouterModule.forRoot(routes),
    BrowserModule, HttpClientModule,
    NgxPaginationModule
],
  providers: [StudentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
