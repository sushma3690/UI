import { Component, OnInit, SimpleChanges } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/common/student';
import { ActivatedRoute,Router} from '@angular/router';


@Component({
  selector: 'app-students-list',
  //templateUrl: './students-list.component.html',
  //templateUrl: './students-list-table.component.html',
  templateUrl: './students-list-grid.component.html',
  styleUrls: ['./students-list.component.css'],
})
export class StudentsListComponent implements OnInit {

 // students: Student[];
 students: Student[] =  [];

 // new properties for pagination
 //thePageNumber: number = 1;
 public thePageNumber: number ;
 //thePageSize: number = 10;
 public thePageSize: number;
 //theTotalElements: number = 0;
 public theTotalElements:number;
 //public numPages: number;

  constructor(private studentService: StudentService,private route: ActivatedRoute, 
    private router: Router) {  }

  
  ngOnInit(): void {
    
    this.thePageSize = 10;
    this.thePageNumber = 1;
    this.theTotalElements = 0;
    this.listStudents(1);
  }
  

listStudents(event) {
  console.log("event", event);
  this.thePageNumber = Number(event);
   // this.studentService.getStudentList().subscribe(
     // data => {
      //  this.students = data;
     // }
   // )
  
   console.log(" list students called with page number and page size", this.thePageNumber, this.thePageSize);
   this.studentService.getStudentListPaginate(this.thePageNumber - 1,
    this.thePageSize)
    .subscribe(this.processResult());
  }

  processResult() {
    return data => {
      this.students = data._embedded.students;
      this.thePageNumber = data.page.number + 1;
      this.thePageSize = data.page.size;
      this.theTotalElements = data.page.totalElements;
    };
  }

 

  



}
