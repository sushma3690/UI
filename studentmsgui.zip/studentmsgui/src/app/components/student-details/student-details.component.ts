import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/common/student';
import { StudentService } from 'src/app/services/student.service';
import { ActivatedRoute , Router, ParamMap} from '@angular/router';

@Component({
  selector: 'app-student-details',
  templateUrl: './student-details.component.html',
  styleUrls: ['./student-details.component.css']
})
export class StudentDetailsComponent implements OnInit {
  student: Student = new Student();

  constructor(private studentService: StudentService,
    private route: ActivatedRoute) { console.log("here11")}

  ngOnInit(): void {
    console.log("here12");
    this.route.params.subscribe(() => {
      console.log("here?")
      this.handleStudentDetails();
    })
  }

  handleStudentDetails() {
    console.log("here13");

    // get the "id" param string. convert string to a number using the "+" symbol
   const theStudentId: number = +this.route.snapshot.paramMap.get('rollNumber');
  // console.log("theStudentId1 "+theStudentId1);
   //const theStudentId: number = 1;
    console.log("paramMap",this.route.snapshot.paramMap);
    console.log("theStudentId ",theStudentId);
    this.studentService.getStudent(theStudentId).subscribe(
      data => {
        this.student = data;
      }
    )
  }

}
